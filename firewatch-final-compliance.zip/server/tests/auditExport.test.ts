
test('audit PDF export contains Spanish entries', async () => {
  const pdf = await exportLanguageAudit([
    { timestamp:'2026-03-01', role:'INSPECTOR', language:'es', source:'organization' }
  ]);
  expect(pdf).toBeInstanceOf(Uint8Array);
});
