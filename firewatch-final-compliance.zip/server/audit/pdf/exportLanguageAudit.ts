
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

export async function exportLanguageAudit(events) {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([600, 800]);
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);

  let y = 750;
  page.drawText('Firewatch Language Audit Report', { x: 50, y, size: 16, font, color: rgb(0,0,0) });
  y -= 40;

  events.forEach(e => {
    page.drawText(`${e.timestamp} | ${e.role} | ${e.language} | ${e.source}`, {
      x: 50, y, size: 10, font
    });
    y -= 14;
  });

  return await pdfDoc.save();
}
