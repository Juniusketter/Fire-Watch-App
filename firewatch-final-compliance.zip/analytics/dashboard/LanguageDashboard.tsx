
import { PieChart, Pie, Tooltip, BarChart, Bar, XAxis, YAxis } from 'recharts';

export default function LanguageDashboard({ data }) {
  return (
    <div>
      <h2>Language Adoption</h2>
      <PieChart width={300} height={300}>
        <Pie data={data.summary} dataKey="value" nameKey="language" />
        <Tooltip />
      </PieChart>

      <h3>By Role</h3>
      <BarChart width={400} height={300} data={data.byRole}>
        <XAxis dataKey="role" />
        <YAxis />
        <Tooltip />
        <Bar dataKey="es" fill="#8884d8" />
        <Bar dataKey="en" fill="#82ca9d" />
      </BarChart>
    </div>
  );
}
