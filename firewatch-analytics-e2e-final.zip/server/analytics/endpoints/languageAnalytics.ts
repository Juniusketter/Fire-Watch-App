
import { Router } from 'express';
const router = Router();

router.get('/analytics/language/summary', async (req, res) => {
  const data = await db.query(`
    SELECT language, COUNT(*) as count
    FROM language_events
    GROUP BY language
  `);
  res.json(data);
});

router.get('/analytics/language/by-role', async (req, res) => {
  const data = await db.query(`
    SELECT role, language, COUNT(*) as count
    FROM language_events
    GROUP BY role, language
  `);
  res.json(data);
});

export default router;
