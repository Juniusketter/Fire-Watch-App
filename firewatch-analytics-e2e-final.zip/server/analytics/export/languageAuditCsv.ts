
export async function exportLanguageAuditCSV(res, events) {
  res.setHeader('Content-Type', 'text/csv');
  res.write('timestamp,role,language,source
');
  events.forEach(e => {
    res.write(`${e.timestamp},${e.role},${e.language},${e.source}
`);
  });
  res.end();
}
