
import { test, expect } from '@playwright/test';

test.use({
  viewport: { width: 1280, height: 800 },
  locale: 'es-ES',
  userAgent: 'Mozilla/5.0 (Linux; Android 9; Fire Tablet)'
});

test('Spanish enforced across sessions on Fire tablet', async ({ page }) => {
  await page.goto('/lang/es');
  await page.click('text=Iniciar sesión');
  await expect(page.locator('text=Panel de control')).toBeVisible();
});
