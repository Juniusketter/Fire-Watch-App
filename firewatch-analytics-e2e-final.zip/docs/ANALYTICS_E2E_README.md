
# Analytics, CSV Export, and Fire Tablet E2E

Includes analytics APIs, CSV audit export, role-filtered dashboards,
and Fire-tablet Playwright tests.
