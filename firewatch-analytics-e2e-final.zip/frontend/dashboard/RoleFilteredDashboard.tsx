
import LanguageDashboard from './LanguageDashboard';

export default function RoleFilteredDashboard({ data, role }) {
  const filtered = data.byRole.filter(r => r.role === role);
  return <LanguageDashboard data={{ summary: data.summary, byRole: filtered }} />;
}
