
export default function OrgLanguageSettings({ org }) {
  return (
    <select value={org.default_language}>
      <option value="en">English</option>
      <option value="es">Español</option>
    </select>
  );
}
