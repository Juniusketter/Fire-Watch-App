
it('renders Spanish for org default language', () => {
  mockUser({ language: 'es', languageSource: 'organization' });
  render(<Dashboard />);
  expect(screen.getByText('Panel de control')).toBeInTheDocument();
});
