
import { Router } from 'express';
const router = Router();

router.patch('/organizations/:id/language', requireRole('ADMIN'), async (req, res) => {
  const { default_language } = req.body;
  await db.organizations.update({ where: { id: req.params.id }, data: { default_language } });
  res.sendStatus(204);
});

export default router;
