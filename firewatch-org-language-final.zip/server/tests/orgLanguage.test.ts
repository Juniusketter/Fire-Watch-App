
it('applies organization default language when user not locked', () => {
  const lang = resolveLanguage({
    user: { language_locked: false },
    organization: { default_language: 'es' },
    browserLang: 'en-US'
  });
  expect(lang).toBe('es');
});
