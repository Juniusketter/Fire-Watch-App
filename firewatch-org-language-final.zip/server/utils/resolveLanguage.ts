
export function resolveLanguage({ user, organization, browserLang }) {
  if (user.language_locked && user.language) return user.language;
  if (organization?.default_language) return organization.default_language;
  if (browserLang?.startsWith('es')) return 'es';
  return 'en';
}
