
ALTER TABLE organizations
ADD COLUMN default_language VARCHAR(5) NOT NULL DEFAULT 'en';

CREATE INDEX idx_org_default_language
ON organizations(default_language);
