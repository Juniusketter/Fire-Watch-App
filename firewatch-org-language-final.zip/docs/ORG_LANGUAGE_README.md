
# Organization Default Language

Organizations can define a default language applied to new and unlocked users.

Priority:
1. User locked language
2. Organization default
3. Browser language
4. System default
